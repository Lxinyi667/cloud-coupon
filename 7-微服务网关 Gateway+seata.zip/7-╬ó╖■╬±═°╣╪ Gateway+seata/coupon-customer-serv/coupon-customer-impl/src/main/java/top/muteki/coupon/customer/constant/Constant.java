package top.muteki.coupon.customer.constant;

/**
 * @author mqxu
 * @date 2023/9/17
 * @description Constant
 **/
public interface Constant {

    String TRAFFIC_VERSION = "traffic-version";

}